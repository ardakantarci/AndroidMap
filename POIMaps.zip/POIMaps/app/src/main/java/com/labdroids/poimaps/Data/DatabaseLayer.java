package com.labdroids.poimaps.Data;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseLayer extends SQLiteOpenHelper{

    public DatabaseLayer(Context c){
        super(c, "PointOfInterest", null, 1);
    }

    public void onCreate (SQLiteDatabase db){
        String sql = " create table PointOfInterest ( " +
                "id integer primary key autoincrement" +
                ", latitude text not null" +
                ", longitude text not null)";

        Cursor cursor = db.rawQuery("select DISTINCT tbl_name from sqlite_master where tbl_name = 'PointOfInterest'", null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                db.execSQL("drop table if exists PointOfInterest");
            }
            cursor.close();
        }
        db.execSQL(sql);

    }

    public void onUpgrade (SQLiteDatabase db, int old_version, int new_version) {
        db.execSQL("drop table if exists PointOfInterest");
    }
}
