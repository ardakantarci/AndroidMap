package com.labdroids.poimaps.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.labdroids.poimaps.Model.PointOfInterest;

import java.util.ArrayList;
import java.util.List;

public class DataSource {

    //sqlite_katmani == DatabaseLayer
    //veriKaynagi == DataSource
    //kullanici == PointOfInterest

    static SQLiteDatabase db;
    static DatabaseLayer mydb;

    public DataSource(Context c){

        mydb = new DatabaseLayer(c);
    }

    public void openConnection(){

        db = mydb.getWritableDatabase();
    }

    public void closeConnection(){
        mydb.close();
    }

    public void createPoint(PointOfInterest poi){
        ContentValues val = new ContentValues();
        val.put("latitude",poi.getLatitude());
        val.put("longitude",poi.getLongitude());
        db.insert("PointOfInterest",null,val);
    }

    public void deletePoint(PointOfInterest poi){
        int id = poi.getId();
        db.delete("PointOfInterest","id="+id,null);
    }

    public static List<PointOfInterest> listPoints(){
        String rows[] = {"id", "latitude", "longitude"};
        List<PointOfInterest> list = new ArrayList<PointOfInterest>();
        Cursor c = db.query("PointOfInterest", rows, null,null,null,null,null);
        c.moveToFirst();
        while(!c.isAfterLast()){
            int id = c.getInt(0);
            String lat = c.getString(1);
            String lon = c.getString(2);
            PointOfInterest p = new PointOfInterest(lat, lon, id);
            list.add(p);
        }

        return list;
    }
}
