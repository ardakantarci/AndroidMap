package com.labdroids.poimaps.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.labdroids.poimaps.Data.DataSource;
import com.labdroids.poimaps.Model.PointOfInterest;
import com.labdroids.poimaps.R;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText totalPoints, maxLatitudeText, minLatitudeText, maxLongitudeText, minLongitudeText;
    public Button createMapButton;
    public String poiNumber, maxLat, minLat, maxLon, minLon;

    DataSource ds = new DataSource(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setupUI();

        createMapButton = (Button) findViewById(R.id.createMapButton);
        createMapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(randomLocation(poiNumber, maxLat, minLat, maxLon, minLon)){

                    navigateMapsActivity();
                }
            }
        });
    }

    public void setupUI() {

        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        ds.openConnection();

        totalPoints = findViewById(R.id.totalPointsText);
        poiNumber = totalPoints.getText().toString();

        maxLatitudeText = findViewById(R.id.maxLatitudeText);
        maxLat = maxLatitudeText.getText().toString();

        minLatitudeText = findViewById(R.id.minLatitudeText);
        minLat = minLatitudeText.getText().toString();

        maxLongitudeText = findViewById(R.id.maxLongitudeText);
        maxLon= maxLongitudeText.getText().toString();

        minLongitudeText = findViewById(R.id.minLongitudeText);
        minLon= minLongitudeText.getText().toString();

    }

    public void navigateMapsActivity() {

        Intent myIntent = new Intent(MainActivity.this,MapsActivity.class);
        startActivity(myIntent);

    }

    public boolean randomLocation(String poiNumber, String matLat, String minLat, String maxLon, String minLon){

        if(poiNumber.isEmpty() || matLat.isEmpty() || minLat.isEmpty() || maxLon.isEmpty() || minLon.isEmpty()){
            return false;
        }

        int pointNumber = Integer.parseInt(poiNumber);
        double maxLatitude = Double.parseDouble(matLat);
        double minLatitude = Double.parseDouble(minLat);
        double maxLongitude = Double.parseDouble(maxLon);
        double minLongitude = Double.parseDouble(minLon);

        Random rand = new Random();

        for(int i=0; i<pointNumber; i++){

            double realLat = minLatitude + (maxLatitude - minLatitude) * rand.nextDouble();
            double realLon = minLongitude + (maxLongitude - minLongitude) * rand.nextDouble();

            PointOfInterest p = new PointOfInterest(Double.toString(realLat), Double.toString(realLon), i);
            ds.createPoint(p);

        }
        ds.closeConnection();

        return true;
    }


}
