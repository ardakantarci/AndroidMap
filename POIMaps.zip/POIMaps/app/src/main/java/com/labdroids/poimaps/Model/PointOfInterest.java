package com.labdroids.poimaps.Model;

public class PointOfInterest {
    int id;
    String longitude, latitude;

    public PointOfInterest(String latitude, String longitude, int id) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String toString(){
        return "" + id + "-" + longitude + "-" + latitude;
    }
}
