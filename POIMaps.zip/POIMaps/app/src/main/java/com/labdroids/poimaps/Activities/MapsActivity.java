package com.labdroids.poimaps.Activities;


import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.labdroids.poimaps.Data.DataSource;
import com.labdroids.poimaps.Model.PointOfInterest;
import com.labdroids.poimaps.R;

import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    DataSource ds = new DataSource(this);

    private double lat = 50.2341;
    private double lon = 23.9845;

    private int getId;
    private double getLatitude;
    private double getLongitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng latLong = new LatLng(lat,lon);
        mMap.addMarker(new MarkerOptions().position(latLong).title("Marker"));

        //getLocations();

        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(50.2341, 23.9845);

        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }

    public void getLocations(){

        LatLng latLong;

        List<PointOfInterest> locationList = DataSource.listPoints();

        for(int i=0; i<locationList.size(); i++){
            PointOfInterest poi = locationList.get(i);
            getId = poi.getId();
            getLatitude = Double.parseDouble(poi.getLatitude());
            getLongitude = Double.parseDouble(poi.getLongitude());

            latLong = new LatLng(lat,lon);
            mMap.addMarker(new MarkerOptions().position(latLong).title("Marker"));
        }

    }

}